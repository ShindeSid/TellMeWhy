import { motion, useReducedMotion } from "framer-motion";

import { formatPercent } from "@/lib/format";
import { useWorkspaceStore } from "@/store/useWorkspaceStore";

function trustColor(value: number): string {
  if (value >= 0.7) return "text-trust-high";
  if (value >= 0.4) return "text-trust-medium";
  return "text-trust-low";
}

function trustRingColor(value: number): string {
  if (value >= 0.7) return "#15803d";
  if (value >= 0.4) return "#a16207";
  return "#c2410c";
}

function TrustGauge({ value }: { value: number }) {
  const pct = Math.round(value * 100);
  const radius = 34;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference * (1 - value);
  const reduceMotion = useReducedMotion();

  return (
    <svg width="88" height="88" viewBox="0 0 88 88" className="shrink-0" role="img" aria-label={`Overall trust ${pct} percent`}>
      <circle cx="44" cy="44" r={radius} fill="none" className="stroke-neutral-200 dark:stroke-neutral-700" strokeWidth="8" />
      <motion.circle
        cx="44"
        cy="44"
        r={radius}
        fill="none"
        stroke={trustRingColor(value)}
        strokeWidth="8"
        strokeLinecap="round"
        strokeDasharray={circumference}
        initial={reduceMotion ? false : { strokeDashoffset: circumference }}
        animate={{ strokeDashoffset: offset }}
        transition={reduceMotion ? { duration: 0 } : { duration: 0.6, ease: "easeOut" }}
        transform="rotate(-90 44 44)"
      />
      <text x="44" y="49" textAnchor="middle" fontSize="18" fontWeight="600" fill="currentColor">
        {pct}%
      </text>
    </svg>
  );
}

export function TrustDashboard() {
  const trustScore = useWorkspaceStore((s) => s.trustScore);
  const status = useWorkspaceStore((s) => s.status);
  const confidenceRecovery = useWorkspaceStore((s) => s.confidenceRecovery);

  if (status !== "ready" && status !== "generating") return null;

  if (!trustScore) {
    return (
      <p className="rounded-xl border border-neutral-200 bg-white p-4 text-xs text-neutral-400 shadow-sm dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-500">
        No trust score available for this answer yet.
      </p>
    );
  }

  return (
    <div className="flex flex-col gap-3 rounded-2xl border border-neutral-200/70 bg-white p-4 shadow-card dark:border-neutral-700/70 dark:bg-neutral-800">
      <h2 className="text-sm font-semibold">How much should you trust this?</h2>
      <div className="flex items-center gap-4">
        <TrustGauge value={trustScore.overall_trust} />
        <p className={`text-sm ${trustColor(trustScore.overall_trust)}`}>
          {trustScore.plain_english_summary}
        </p>
      </div>

      {confidenceRecovery && (
        <div className="flex items-center gap-2 rounded-lg bg-trust-high/10 px-3 py-2 text-sm text-trust-high">
          <span aria-hidden="true">✓</span>
          <span className="font-medium">
            Confidence recovered +{formatPercent(confidenceRecovery.delta)}
          </span>
          <span className="text-xs text-trust-high/80">- {confidenceRecovery.reason}</span>
        </div>
      )}
      <dl className="grid grid-cols-3 gap-2 text-center text-xs text-neutral-500 dark:text-neutral-400">
        <div className="rounded-lg bg-neutral-50 p-2 dark:bg-neutral-700/50">
          <dt>Fact-checked</dt>
          <dd className="mt-0.5 text-sm font-semibold text-neutral-900 dark:text-neutral-100">
            {trustScore.verification_score !== null ? formatPercent(trustScore.verification_score) : "n/a"}
          </dd>
        </div>
        <div className="rounded-lg bg-neutral-50 p-2 dark:bg-neutral-700/50">
          <dt>Up to date</dt>
          <dd className="mt-0.5 text-sm font-semibold text-neutral-900 dark:text-neutral-100">
            {trustScore.freshness_score !== null ? formatPercent(trustScore.freshness_score) : "n/a"}
          </dd>
        </div>
        <div className="rounded-lg bg-neutral-50 p-2 dark:bg-neutral-700/50">
          <dt>How thorough</dt>
          <dd className="mt-0.5 text-sm font-semibold text-neutral-900 dark:text-neutral-100">
            {formatPercent(trustScore.reasoning_depth_score ?? 0)}
          </dd>
        </div>
      </dl>
    </div>
  );
}
